import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SearchService {

  http:HttpClient;
  pro:Products[]=[];

  constructor(http:HttpClient) {
   this.http=http;
   this.fetchProducts();
   }

   fetched:boolean=false;
   fetchProducts()
   {
     this.http.get('./assets/product.json')
     .subscribe(
       data=>{
         if(!this.fetched)
         {
           this.convert(data);
           this.fetched=true;
         }
       }
     );
   }
   getProducts():Products[]
   {
     return this.pro;
   }
   
   convert(data:any)
   {
     for(let prod of data["products"])
     {
       let p=new Products(prod.id,prod.name,prod.price,prod.category);
       this.pro.push(p);
     }
   }

   delete(id:number)
   {
     let index:number=-1;
     for(let i=0;i<this.pro.length;i++)
     {
       let p=this.pro[i];
       if(id==p.id)
       {
         index=i;
         break;
       }
     }
     this.pro.splice(index,1);
   }

   search(name:string):Products[]
  {
    let result:Products[]=[];
    let o:Products;
    var flag=0;
    for(let i=0;i<this.pro.length;i++)
    {
      o=this.pro[i];
      if(name==o.name)
      {
        result.push(o);
        flag=1;
      }
    }if(flag==0)
    {
      alert(name +" doesn't exists");
    }
    return result;
  }

}

export class Products
{
  id:any;
  name:any;
  price:any;
  category:any;
  constructor(id:any,name:any,price:any,category:any)
  {
    this.id=id;
    this.name=name;
    this.price=price;
    this.category=category;
  }
}