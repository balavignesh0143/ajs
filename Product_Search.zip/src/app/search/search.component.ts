import { Component, OnInit } from '@angular/core';
import { Products, SearchService } from '../search.service';
import { privateEncrypt } from 'crypto';
import { stringify } from '@angular/compiler/src/util';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  pro:Products[]=[];

  service:SearchService;
  constructor(service:SearchService) {
    this.service=service;
   }

  ngOnInit() {
    this.service.fetchProducts();
  }

  search(data:any)
  {
    let name:string=data.name;
    //let cat:string=data.category;
    this.pro=this.service.search(name);
  }
}
