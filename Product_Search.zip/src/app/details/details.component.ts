import { Component, OnInit } from '@angular/core';
import { SearchService, Products } from '../search.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  service:SearchService;
  
  constructor(service:SearchService) {
    this.service=service;
   }

   pro:Products[]=[];

   delete(id:number)
   {
     this.service.delete(id);
     this.pro=this.service.getProducts();
   }

  ngOnInit() {
    this.service.fetchProducts();
    this.pro=this.service.getProducts();
  }

}
